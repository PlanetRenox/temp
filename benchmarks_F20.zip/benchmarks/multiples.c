#include<stdio.h>

int main() {

   int count = 0, max = 5000, nocount7=0, nocount13=0;;

      for(int i=1;i<=max;i++) {    

         if(i%7==0 || i%13 ==0) {

            count++;
            
         }
         else if(!(i%7==0)){

         	nocount7++;

         }
         else if(!(i%13==0)){

         	nocount13++;

         }


      }

      printf("Total numbers not divisible by 7 or 13 are : %d\n", (nocount7 + nocount13));

return 0;

}